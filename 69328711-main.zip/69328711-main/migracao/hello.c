#include <stdio.h>
#include <cs50.h>

int main(void){
    string nome = get_string("Qual seu nome? \n");

    printf("Hello, %s !!!\n", nome);
}